# CST816S
 An Arduino library for the CST816S capacitive touch screen IC
 
 [![arduino-library-badge](https://www.ardu-badge.com/badge/CST816S.svg?)](https://www.arduinolibraries.info/libraries/cst816-s)